﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using RRC;

namespace StudentTestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();

            Console.WriteLine("ID: {0}", student.GetId());
            Console.WriteLine("First Name: {0}", student.GetFirstName());
            Console.WriteLine("Last Name: {0}\n", student.GetLastName());

            student.SetId(12345);
            student.SetFirstName("A.J.");
            student.SetLastName("Styles");

            Console.WriteLine("ID: {0}", student.GetId());
            Console.WriteLine("First Name: {0}", student.GetFirstName());
            Console.WriteLine("Last Name: {0}\n", student.GetLastName());

            Console.Write("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
